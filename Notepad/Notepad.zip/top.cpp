//
// Created by Dell on 2018/4/25.
//
#include "ASM.h"
#include "DIS.h"

string asm_all(string file_addr)
{
    assembler A;
    A.set_state();
    A.read_text_addr(file_addr);
    A.text_processing();
    A.first_scan();
    A.second_scan();

    //检查编译是否正确
    if(A.get_state_out() == "Compile successfully!")
    {
        cout<<A.get_file_out_name();
        return A.get_file_out_name();
    }
    else
    {
        cout<<A.get_state_out();
        return A.get_state_out();
    }
}

string asm_state(string file_addr)
{
    assembler A;
    A.set_state();
    A.read_text_addr(file_addr);
    A.text_processing();
    A.first_scan();
    A.second_scan();
    cout<<A.get_state_out();
    return A.get_state_out();
}

string dis_all(string file_addr)
{
    dissembler D;
    int state;
    D.set_state();
    D.read_text_addr("machine.txt");
    state = D.text_processing();
    if(state == 1)
    {
        cout<<D.get_file_out_name();
        return D.get_file_out_name();
    }
    else
    {
        cout<<D.get_state_out();
        return D.get_state_out();
    }
}

string dis_state(string file_addr)
{
    dissembler D;
    D.set_state();
    D.read_text_addr(file_addr);
    D.text_processing();
    cout<<D.get_state_out();
    return D.get_state_out();
}