#pragma once
#include <string>
std::string func(std::string file_path);